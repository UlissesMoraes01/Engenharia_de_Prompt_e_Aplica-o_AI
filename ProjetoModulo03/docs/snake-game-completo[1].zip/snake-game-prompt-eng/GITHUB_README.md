# 🐍 Snake Game - Engenharia de Prompt

Um jogo da cobrinha funcional desenvolvido com **IA e Engenharia de Prompt**, utilizando React 19, Tailwind CSS 4 e Canvas API. Projeto acadêmico para a disciplina de Engenharia de Prompt (Módulo 3).

## 🎮 Características

- ✅ Jogo da cobrinha totalmente funcional
- ✅ Design Retro Arcade Neon com efeitos visuais sofisticados
- ✅ Controles intuitivos (setas direcionais, WASD)
- ✅ Sistema de pontuação e velocidade progressiva
- ✅ Detecção de colisão e wraparound de paredes
- ✅ Interface responsiva

## 🚀 Como Usar

### Pré-requisitos
- Node.js 22+ 
- pnpm 10+

### Instalação

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/snake-game-prompt-eng.git
cd snake-game-prompt-eng

# Instale as dependências
pnpm install

# Inicie o servidor de desenvolvimento
pnpm dev
```

O jogo estará disponível em `http://localhost:3000`

### Build para Produção

```bash
pnpm build
pnpm preview
```

## 🎮 Como Jogar

- **Setas Direcionais** ou **WASD** - Mover a cobrinha
- **Espaço/Enter** - Iniciar o jogo
- **PAUSE** - Pausar/Retomar
- **RESET** - Reiniciar do zero

**Objetivo:** Coletar a comida amarela para aumentar a pontuação. Evite colidir com o próprio corpo!

## 📁 Estrutura do Projeto

```
snake-game-prompt-eng/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   └── Home.tsx          # Componente principal do jogo
│   │   ├── index.css             # Estilos globais + animações neon
│   │   └── App.tsx               # Configuração da aplicação
│   ├── public/                   # Arquivos estáticos
│   └── index.html
├── docs/
│   ├── README.md                 # Documentação completa do projeto
│   ├── DOCUMENTACAO.pdf          # Versão em PDF
│   └── *.png                     # Screenshots do jogo
├── ideas.md                      # Brainstorming de design
├── package.json
└── README.md                     # Este arquivo
```

## 🛠️ Stack Tecnológico

- **Frontend:** React 19 + TypeScript
- **Estilização:** Tailwind CSS 4
- **Renderização:** Canvas API
- **Build:** Vite
- **Hospedagem:** Manus AI

## 📚 Documentação

Veja o arquivo `/docs/README.md` ou `/docs/DOCUMENTACAO.pdf` para documentação completa do projeto, incluindo:
- Desafio proposto
- Análise de vantagens e limitações
- Reflexão crítica sobre Engenharia de Prompt
- Próximos passos e melhorias sugeridas

## 🎨 Design

O jogo utiliza um tema visual **Retro Arcade Neon** com:
- Cores vibrantes (magenta, ciano, amarelo)
- Efeitos glow e brilho neon
- Animações pulsantes
- Borda interativa ao redor do canvas

## 📊 Geração de Código por IA

Este projeto foi desenvolvido utilizando **Engenharia de Prompt** com o Manus AI:
- 80% do código foi gerado por IA
- 20% foi refinado e validado manualmente
- Demonstra como IA pode acelerar desenvolvimento sem sacrificar qualidade

## 🚀 Próximas Melhorias

- [ ] Sistema de ranking com localStorage
- [ ] Modo dificuldade (Fácil/Normal/Difícil)
- [ ] Efeitos sonoros
- [ ] Suporte mobile com controles touchscreen
- [ ] Multiplayer local
- [ ] Temas visuais adicionais

## 📝 Licença

Este projeto é fornecido como material educacional para a disciplina de Engenharia de Prompt.

## 👥 Autores

Desenvolvido como projeto acadêmico em colaboração com Manus AI.

---

**Acesse o jogo ao vivo:** [Clique aqui para jogar](https://seu-dominio.com)

**Documentação Completa:** Veja `/docs/DOCUMENTACAO.pdf`
