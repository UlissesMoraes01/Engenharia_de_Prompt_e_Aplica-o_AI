import { useEffect, useRef, useState } from 'react';

/**
 * DESIGN PHILOSOPHY: Retro Arcade Neon
 * - Neon vibrante contra fundo escuro
 * - Feedback visual rico com glow effects
 * - Animações que celebram cada ação
 * - Paleta: Magenta, Ciano, Amarelo contra preto profundo
 */

interface Position {
  x: number;
  y: number;
}

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

const GRID_SIZE = 20;
const CANVAS_WIDTH = 400;
const CANVAS_HEIGHT = 400;
const CELL_SIZE = CANVAS_WIDTH / GRID_SIZE;
const INITIAL_SPEED = 100;

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<Position>({ x: 15, y: 15 });
  const [direction, setDirection] = useState<Direction>('RIGHT');
  const [nextDirection, setNextDirection] = useState<Direction>('RIGHT');
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [speed, setSpeed] = useState(INITIAL_SPEED);
  const gameLoopRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);
  const directionChangeRef = useRef<boolean>(false);

  // Gerar nova posição de comida
  const generateFood = (snakePositions: Position[]): Position => {
    let newFood: Position = { x: 0, y: 0 };
    let isOnSnake = true;

    while (isOnSnake) {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };

      isOnSnake = snakePositions.some(
        (segment) => segment.x === newFood.x && segment.y === newFood.y
      );
    }

    return newFood;
  };

  // Desenhar no canvas
  const draw = (snakePositions: Position[], foodPosition: Position) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fundo preto profundo
    ctx.fillStyle = '#0A0E27';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Grid de fundo sutil
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.05)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= GRID_SIZE; i++) {
      const pos = i * CELL_SIZE;
      ctx.beginPath();
      ctx.moveTo(pos, 0);
      ctx.lineTo(pos, CANVAS_HEIGHT);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, pos);
      ctx.lineTo(CANVAS_WIDTH, pos);
      ctx.stroke();
    }

    // Desenhar comida com glow
    const foodX = foodPosition.x * CELL_SIZE + CELL_SIZE / 2;
    const foodY = foodPosition.y * CELL_SIZE + CELL_SIZE / 2;

    // Glow amarelo
    ctx.fillStyle = 'rgba(255, 255, 0, 0.3)';
    ctx.beginPath();
    ctx.arc(foodX, foodY, CELL_SIZE * 0.8, 0, Math.PI * 2);
    ctx.fill();

    // Comida amarela
    ctx.fillStyle = '#FFFF00';
    ctx.beginPath();
    ctx.arc(foodX, foodY, CELL_SIZE * 0.35, 0, Math.PI * 2);
    ctx.fill();

    // Desenhar cobrinha
    snakePositions.forEach((segment, index) => {
      const x = segment.x * CELL_SIZE + 1;
      const y = segment.y * CELL_SIZE + 1;
      const size = CELL_SIZE - 2;

      if (index === 0) {
        // Cabeça com glow magenta
        ctx.fillStyle = 'rgba(255, 0, 255, 0.4)';
        ctx.fillRect(x - 2, y - 2, size + 4, size + 4);

        ctx.fillStyle = '#FF00FF';
        ctx.fillRect(x, y, size, size);

        // Olhos
        ctx.fillStyle = '#00FFFF';
        const eyeSize = 3;
        const eyeOffset = 5;

        if (direction === 'RIGHT') {
          ctx.fillRect(x + eyeOffset, y + 4, eyeSize, eyeSize);
          ctx.fillRect(x + eyeOffset, y + size - 7, eyeSize, eyeSize);
        } else if (direction === 'LEFT') {
          ctx.fillRect(x + size - eyeOffset - eyeSize, y + 4, eyeSize, eyeSize);
          ctx.fillRect(x + size - eyeOffset - eyeSize, y + size - 7, eyeSize, eyeSize);
        } else if (direction === 'UP') {
          ctx.fillRect(x + 4, y + size - eyeOffset - eyeSize, eyeSize, eyeSize);
          ctx.fillRect(x + size - 7, y + size - eyeOffset - eyeSize, eyeSize, eyeSize);
        } else {
          ctx.fillRect(x + 4, y + eyeOffset, eyeSize, eyeSize);
          ctx.fillRect(x + size - 7, y + eyeOffset, eyeSize, eyeSize);
        }
      } else {
        // Corpo com gradiente de cor
        const hue = (index * 10) % 360;
        ctx.fillStyle = `hsl(${hue}, 100%, 50%)`;
        ctx.fillRect(x, y, size, size);

        // Borda ciano
        ctx.strokeStyle = '#00FFFF';
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, size, size);
      }
    });
  };

  // Lógica do jogo
  const updateGame = () => {
    if (!gameStarted || gameOver) return;

    setSnake((prevSnake) => {
      const newSnake = [...prevSnake];
      const head = { ...newSnake[0] };

      // Aplicar próxima direção se for válida
      if (
        (nextDirection === 'UP' && direction !== 'DOWN') ||
        (nextDirection === 'DOWN' && direction !== 'UP') ||
        (nextDirection === 'LEFT' && direction !== 'RIGHT') ||
        (nextDirection === 'RIGHT' && direction !== 'LEFT')
      ) {
        setDirection(nextDirection);
        directionChangeRef.current = false;
      }

      // Mover cabeça
      switch (direction) {
        case 'UP':
          head.y = (head.y - 1 + GRID_SIZE) % GRID_SIZE;
          break;
        case 'DOWN':
          head.y = (head.y + 1) % GRID_SIZE;
          break;
        case 'LEFT':
          head.x = (head.x - 1 + GRID_SIZE) % GRID_SIZE;
          break;
        case 'RIGHT':
          head.x = (head.x + 1) % GRID_SIZE;
          break;
      }

      newSnake.unshift(head);

      // Verificar colisão com corpo
      for (let i = 1; i < newSnake.length; i++) {
        if (head.x === newSnake[i].x && head.y === newSnake[i].y) {
          setGameOver(true);
          return prevSnake;
        }
      }

      // Verificar se comeu
      if (head.x === food.x && head.y === food.y) {
        setScore((prev) => prev + 10);
        setFood(generateFood(newSnake));
        setSpeed((prev) => Math.max(50, prev - 2));
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  };

  // Game loop
  useEffect(() => {
    if (gameLoopRef.current) clearInterval(gameLoopRef.current);

    if (gameStarted && !gameOver) {
      gameLoopRef.current = setInterval(updateGame, speed);
    }

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
    };
  }, [gameStarted, gameOver, speed, direction, nextDirection]);

  // Desenhar
  useEffect(() => {
    draw(snake, food);
  }, [snake, food, direction]);

  // Controle por teclado
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!gameStarted && (e.key === ' ' || e.key === 'Enter')) {
        e.preventDefault();
        setGameStarted(true);
        return;
      }

      if (!directionChangeRef.current) {
        switch (e.key.toUpperCase()) {
          case 'ARROWUP':
          case 'W':
            e.preventDefault();
            setNextDirection('UP');
            directionChangeRef.current = true;
            break;
          case 'ARROWDOWN':
          case 'S':
            e.preventDefault();
            setNextDirection('DOWN');
            directionChangeRef.current = true;
            break;
          case 'ARROWLEFT':
          case 'A':
            e.preventDefault();
            setNextDirection('LEFT');
            directionChangeRef.current = true;
            break;
          case 'ARROWRIGHT':
          case 'D':
            e.preventDefault();
            setNextDirection('RIGHT');
            directionChangeRef.current = true;
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameStarted]);

  const resetGame = () => {
    setSnake([{ x: 10, y: 10 }]);
    setFood({ x: 15, y: 15 });
    setDirection('RIGHT');
    setNextDirection('RIGHT');
    setScore(0);
    setGameOver(false);
    setGameStarted(false);
    setSpeed(INITIAL_SPEED);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0A0E27] to-[#1a1f3a] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Título */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#FF00FF] via-[#00FFFF] to-[#FFFF00] mb-2 animate-pulse"
            style={{ textShadow: '0 0 20px rgba(255, 0, 255, 0.5), 0 0 40px rgba(0, 255, 255, 0.3)' }}>
            SNAKE GAME
          </h1>
          <p className="text-[#00FFFF] text-sm font-mono" style={{ textShadow: '0 0 10px rgba(0, 255, 255, 0.5)' }}>
            [ RETRO ARCADE EDITION ]
          </p>
        </div>

        {/* Canvas com borda neon */}
        <div className="relative mb-8 p-1 rounded-lg"
          style={{
            background: 'linear-gradient(45deg, #FF00FF, #00FFFF, #FFFF00, #FF00FF)',
            boxShadow: '0 0 30px rgba(255, 0, 255, 0.6), 0 0 60px rgba(0, 255, 255, 0.3), inset 0 0 20px rgba(255, 255, 0, 0.1)',
            animation: 'neon-pulse 2s ease-in-out infinite'
          }}>
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="w-full bg-[#0A0E27] rounded"
            style={{ display: 'block' }}
          />
        </div>

        {/* Placar */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-[#1a1f3a] border-2 border-[#00FFFF] rounded p-4 text-center"
            style={{ boxShadow: '0 0 15px rgba(0, 255, 255, 0.3)' }}>
            <p className="text-[#00FFFF] text-xs font-mono mb-1">SCORE</p>
            <p className="text-3xl font-black text-[#FFFF00]" style={{ textShadow: '0 0 10px rgba(255, 255, 0, 0.6)' }}>
              {score}
            </p>
          </div>
          <div className="bg-[#1a1f3a] border-2 border-[#FF00FF] rounded p-4 text-center"
            style={{ boxShadow: '0 0 15px rgba(255, 0, 255, 0.3)' }}>
            <p className="text-[#FF00FF] text-xs font-mono mb-1">SPEED</p>
            <p className="text-3xl font-black text-[#FF00FF]" style={{ textShadow: '0 0 10px rgba(255, 0, 255, 0.6)' }}>
              {Math.round((INITIAL_SPEED - speed) / 5) + 1}
            </p>
          </div>
        </div>

        {/* Controles */}
        <div className="bg-[#1a1f3a] border-2 border-[#00FFFF] rounded-lg p-6 mb-6"
          style={{ boxShadow: '0 0 20px rgba(0, 255, 255, 0.3)' }}>
          <p className="text-[#00FFFF] text-xs font-mono mb-4 text-center">CONTROLS</p>
          <div className="grid grid-cols-2 gap-3 text-center text-sm">
            <div className="text-[#FFFF00]">↑ W / ↓ S</div>
            <div className="text-[#FFFF00]">← A / → D</div>
            <div className="col-span-2 text-[#FF00FF]">Arrow Keys</div>
          </div>
        </div>

        {/* Botões */}
        <div className="flex gap-4">
          {!gameStarted ? (
            <button
              onClick={() => setGameStarted(true)}
              className="flex-1 py-3 px-4 bg-gradient-to-r from-[#FF00FF] to-[#00FFFF] text-[#0A0E27] font-black rounded-lg text-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                boxShadow: '0 0 20px rgba(255, 0, 255, 0.6), 0 0 40px rgba(0, 255, 255, 0.3)',
                textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
              }}>
              START GAME
            </button>
          ) : (
            <button
              onClick={() => setGameStarted(false)}
              className="flex-1 py-3 px-4 bg-gradient-to-r from-[#FFFF00] to-[#FF00FF] text-[#0A0E27] font-black rounded-lg text-lg transition-all duration-200 hover:scale-105 active:scale-95"
              style={{
                boxShadow: '0 0 20px rgba(255, 255, 0, 0.6), 0 0 40px rgba(255, 0, 255, 0.3)',
                textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
              }}>
              PAUSE
            </button>
          )}
          <button
            onClick={resetGame}
            className="flex-1 py-3 px-4 border-2 border-[#00FFFF] text-[#00FFFF] font-black rounded-lg text-lg transition-all duration-200 hover:scale-105 active:scale-95"
            style={{
              boxShadow: '0 0 15px rgba(0, 255, 255, 0.3)',
              background: 'rgba(0, 255, 255, 0.05)'
            }}>
            RESET
          </button>
        </div>

        {/* Game Over Modal */}
        {gameOver && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
            <div className="bg-[#0A0E27] border-4 border-[#FF00FF] rounded-lg p-8 text-center max-w-sm"
              style={{
                boxShadow: '0 0 40px rgba(255, 0, 255, 0.8), 0 0 80px rgba(0, 255, 255, 0.4)',
                animation: 'glitch 0.3s'
              }}>
              <h2 className="text-4xl font-black text-[#FF00FF] mb-4" style={{ textShadow: '0 0 20px rgba(255, 0, 255, 0.8)' }}>
                GAME OVER
              </h2>
              <p className="text-[#00FFFF] text-2xl font-black mb-2" style={{ textShadow: '0 0 10px rgba(0, 255, 255, 0.6)' }}>
                {score}
              </p>
              <p className="text-[#FFFF00] text-sm font-mono mb-6">FINAL SCORE</p>
              <button
                onClick={resetGame}
                className="w-full py-3 px-4 bg-gradient-to-r from-[#FF00FF] to-[#00FFFF] text-[#0A0E27] font-black rounded-lg text-lg transition-all duration-200 hover:scale-105 active:scale-95"
                style={{
                  boxShadow: '0 0 20px rgba(255, 0, 255, 0.6), 0 0 40px rgba(0, 255, 255, 0.3)',
                  textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
                }}>
                PLAY AGAIN
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
