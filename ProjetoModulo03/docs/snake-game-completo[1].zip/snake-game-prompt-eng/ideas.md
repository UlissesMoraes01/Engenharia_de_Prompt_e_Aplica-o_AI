# Brainstorming de Design - Jogo da Cobrinha

## Ideia 1: Retro Arcade Neon (Probabilidade: 0.08)

**Movimento de Design:** Cyberpunk dos anos 80/90 com influência arcade clássica

**Princípios Centrais:**
- Neon vibrante contra fundo escuro (tema noturno)
- Pixelização controlada e linhas geométricas nítidas
- Contraste extremo para legibilidade máxima
- Energia visual constante através de cores saturadas

**Filosofia de Cores:**
Paleta neon: magenta (#FF00FF), ciano (#00FFFF), amarelo elétrico (#FFFF00), com fundo preto profundo (#0A0E27). O objetivo é evocar a nostalgia arcade enquanto mantém modernidade através de efeitos de brilho (glow) e sombras coloridas.

**Paradigma de Layout:**
Grid centralizado com borda neon pulsante. O jogo ocupa o centro da tela com painel de controle abaixo. Elementos flutuam em diferentes profundidades com sombras coloridas.

**Elementos Assinatura:**
- Borda neon pulsante ao redor do canvas
- Efeito de "scan lines" horizontal sutil
- Números e pontuação em fonte pixelada estilo arcade
- Partículas de luz quando a cobrinha come comida

**Filosofia de Interação:**
Cliques e teclas produzem feedback visual imediato: sons retrô, flashes de cor, efeitos de partículas. Cada ação é celebrada visualmente.

**Animação:**
- Borda do jogo pulsa continuamente (opacity 0.6 → 1.0 em 1.5s)
- Pontuação anima com escala e cor quando atualiza
- Cobrinha se move suavemente com transição de 100ms entre frames
- Game Over exibe com efeito de glitch (deslocamento horizontal rápido)

**Sistema Tipográfico:**
Fonte pixelada (Press Start 2P) para títulos e pontuação. Fonte sans-serif moderna (Orbitron) para instruções. Contraste entre retro e contemporâneo.

---

## Ideia 2: Minimalismo Geométrico Moderno (Probabilidade: 0.07)

**Movimento de Design:** Design escandinavo com influência de geometria abstrata

**Princípios Centrais:**
- Espaço em branco abundante
- Formas geométricas puras (quadrados, linhas)
- Paleta limitada de 3-4 cores
- Tipografia clara e hierárquica

**Filosofia de Cores:**
Fundo branco limpo (#FFFFFF), cobrinha em azul profundo (#2C3E50), comida em coral quente (#FF6B6B), com acentos em cinza neutro (#ECF0F1). Simplicidade radical com propósito.

**Paradigma de Layout:**
Grid assimétrico com o jogo posicionado ligeiramente descentrado. Controles e pontuação distribuídos organicamente ao redor, não em blocos densos. Muito ar negativo.

**Elementos Assinatura:**
- Grid de fundo muito sutil (linhas cinza 5% opacity)
- Números com fonte geométrica e peso fino
- Indicadores de direção como setas simples
- Animação de "pulse" suave na comida

**Filosofia de Interação:**
Interações silenciosas e elegantes. Sem sons, apenas feedback visual suave. Transições suaves e previsíveis. Sensação de controle e precisão.

**Animação:**
- Movimento da cobrinha com transição suave de 80ms
- Comida respira levemente (scale 1.0 → 1.15 em 2s, loop)
- Game Over com fade-out suave e reaparição de botão
- Transições entre telas com dissolve de 300ms

**Sistema Tipográfico:**
Montserrat para títulos (peso 700). Inter para corpo (peso 400). Espaçamento generoso entre linhas e letras.

---

## Ideia 3: Playful Illustration com Gradientes Suaves (Probabilidade: 0.06)

**Movimento de Design:** Ilustração contemporânea com influência de design de personagens

**Princípios Centrais:**
- Gradientes suaves e cores pastel
- Ilustrações customizadas (cobrinha com olhos, comida com expressão)
- Bordas arredondadas em tudo
- Sensação lúdica e acessível

**Filosofia de Cores:**
Gradiente de fundo suave (violeta claro #E8D5F2 → azul pastel #D5E8F7). Cobrinha em verde menta (#A8D8BA) com detalhes em branco. Comida em laranja quente (#FFB347). Paleta aquecida e convidativa.

**Paradigma de Layout:**
Composição orgânica com elementos flutuando em diferentes alturas. Nada alinhado rigidamente. Cards arredondados para pontuação e controles. Sensação de movimento e leveza.

**Elementos Assinatura:**
- Cobrinha com olhos e expressão
- Comida com pequenas folhas ou brilho
- Nuvens decorativas no fundo
- Confete ao atingir marcos de pontuação

**Filosofia de Interação:**
Feedback positivo e encorajador. Animações que celebram o sucesso. Sons suaves e musicais. Sensação de jogo acessível e divertido.

**Animação:**
- Cobrinha pisca os olhos ocasionalmente
- Comida "flutua" levemente (translateY -5px em 2s, loop)
- Pontuação anima com confete (CSS animation)
- Game Over com balançar suave (shake 5px)

**Sistema Tipográfico:**
Fredoka para títulos (peso 600, arredondado). Poppins para corpo (peso 500). Espaçamento confortável e respiração visual.

---

## Decisão Final

**Abordagem Selecionada: Retro Arcade Neon**

Esta abordagem foi escolhida porque:
1. Cria identidade visual forte e memorável
2. Alinha perfeitamente com a temática clássica do jogo da cobrinha
3. Oferece feedback visual rico sem ser excessivo
4. Demonstra domínio de efeitos visuais modernos (glow, animações)
5. Diferencia-se de implementações genéricas de jogo da cobrinha
