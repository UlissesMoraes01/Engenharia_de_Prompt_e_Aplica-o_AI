# Projeto Módulo 3 – Low Code/No Code/Vibecode

## 📌 Desafio Escolhido

O desafio proposto consiste no desenvolvimento de um **jogo da cobrinha (Snake Game) totalmente funcional** utilizando tecnologias de **Engenharia de Prompt e código gerado por IA**. O projeto demonstra como ferramentas de inteligência artificial podem ser utilizadas para acelerar o desenvolvimento de aplicações interativas, desde a concepção até a implementação completa, sem necessidade de conhecimento profundo em programação tradicional.

O jogo implementa todas as mecânicas clássicas do Snake: movimento da cobrinha em um grid, colisão com paredes (com wraparound), coleta de comida, aumento de velocidade progressivo, detecção de colisão com o próprio corpo e sistema de pontuação em tempo real.

---

## 🖥️ Protótipo

### Telas Capturadas

#### Tela Inicial
![Tela Inicial do Jogo](tela-inicial.png)

A tela inicial apresenta a interface principal do jogo com o título "SNAKE GAME" em estilo neon, a área de jogo (canvas) com a cobrinha (em magenta) e a comida (em amarelo), além dos controles de pontuação e velocidade.

#### Jogo em Andamento
![Jogo em Andamento](jogo-em-andamento.png)

Durante o gameplay, o jogo exibe o estado atual com a cobrinha se movimentando, a comida disponível para coleta, e o sistema de pontuação sendo atualizado em tempo real.

#### Gameplay Ativo
![Gameplay Ativo](jogo-gameplay.png)

A captura mostra a cobrinha em movimento, demonstrando a responsividade do jogo aos comandos do teclado e a fluidez das animações.

### Funcionamento do Protótipo

O protótipo funciona como um jogo da cobrinha clássico com as seguintes características:

**Mecânicas Principais:**
- A cobrinha começa com um segmento no centro do grid 20x20
- O jogador controla a direção da cobrinha usando as teclas de seta ou WASD
- Quando a cobrinha colide com a comida, o corpo cresce e a pontuação aumenta em 10 pontos
- A velocidade do jogo aumenta progressivamente conforme o jogador coleta mais comida
- Se a cobrinha colidir com seu próprio corpo, o jogo termina
- As paredes possuem wraparound (a cobrinha reaparece do lado oposto ao atravessar uma borda)

**Interface Visual:**
- Design em estilo Retro Arcade Neon com cores vibrantes (magenta, ciano, amarelo)
- Borda pulsante ao redor do canvas com efeito glow
- Placar exibindo pontuação atual e nível de velocidade
- Painel de controles com instruções claras
- Modal de Game Over com opção de reiniciar

**Controles:**
- Setas direcionais ou WASD para mover a cobrinha
- Espaço ou Enter para iniciar o jogo
- Botão PAUSE para pausar/retomar
- Botão RESET para reiniciar do zero

---

## ⚙️ Plataforma Utilizada

### Nome da Plataforma

**Manus AI + React 19 + Tailwind CSS 4 + Canvas API**

### Justificativa da Escolha

A escolha dessa stack tecnológica foi fundamentada em diversos fatores:

**1. Engenharia de Prompt com Manus AI:**
O Manus AI foi selecionado como a plataforma principal de geração de código porque oferece capacidades avançadas de compreensão de linguagem natural e pode gerar código React completo e funcional a partir de descrições em português. Isso alinha perfeitamente com o objetivo da disciplina de demonstrar como a IA pode acelerar o desenvolvimento sem necessidade de programação manual.

**2. React 19:**
React foi escolhido por ser um framework moderno e amplamente utilizado para desenvolvimento de interfaces interativas. Sua abordagem baseada em componentes permite reutilização de código e facilita a manutenção. O React 19 oferece melhorias significativas em performance e desenvolvimento.

**3. Tailwind CSS 4:**
Tailwind CSS foi selecionado para estilização porque permite criar designs sofisticados rapidamente através de utilitários CSS pré-definidos, sem necessidade de escrever CSS customizado extensivo. Sua integração com React é perfeita para desenvolvimento ágil.

**4. Canvas API:**
A Canvas API foi utilizada para renderizar o jogo porque oferece controle pixel-perfeito sobre a renderização gráfica, permitindo criar efeitos visuais neon complexos e animações suaves que seriam difíceis de implementar com DOM tradicional.

**5. Hospedagem no Manus:**
A plataforma Manus fornece hospedagem integrada, versionamento automático, e ferramentas de desenvolvimento que eliminam a necessidade de configurar infraestrutura, permitindo focar totalmente no desenvolvimento da aplicação.

---

## ✅ Vantagens Identificadas

### 1. Prototipagem Rápida e Iterativa

A utilização de IA para geração de código permitiu transformar a ideia do jogo em um protótipo funcional em questão de minutos, em vez de horas. O Manus AI compreendeu os requisitos em linguagem natural e gerou código React estruturado e funcional. Isso demonstra como a Engenharia de Prompt pode acelerar significativamente o ciclo de desenvolvimento, permitindo que mais tempo seja dedicado ao design e refinamento em vez de codificação manual repetitiva.

### 2. Integração Perfeita com Ferramentas Modernas

A plataforma Manus oferece integração seamless com React, Tailwind CSS, e ferramentas de desenvolvimento modernas. O servidor de desenvolvimento (Vite) reinicia automaticamente quando arquivos são modificados, e a plataforma gerencia automaticamente dependências, build e deploy. Isso elimina overhead operacional e permite que o desenvolvedor foque na lógica da aplicação.

### 3. Customização Visual Sofisticada sem Complexidade

Tailwind CSS permitiu criar um design Retro Arcade Neon visualmente sofisticado com efeitos de glow, animações pulsantes e gradientes, tudo através de classes utilitárias simples. Sem Tailwind, seria necessário escrever CSS customizado extensivo. A combinação de Tailwind com Canvas API possibilitou efeitos visuais que normalmente exigiriam bibliotecas gráficas especializadas.

### 4. Escalabilidade e Manutenibilidade

O código gerado pela IA segue padrões React modernos com hooks, separação de concerns, e estrutura modular. Isso significa que o projeto pode ser facilmente estendido com novas funcionalidades (por exemplo: múltiplos níveis, power-ups, multiplayer) sem refatoração extensiva do código existente.

### 5. Ausência de Configuração Complexa

Diferentemente de ferramentas tradicionais que exigem configuração de webpack, babel, e outras ferramentas de build, o Manus fornece um ambiente pré-configurado que "funciona fora da caixa". Isso reduz a curva de aprendizado e permite que iniciantes foquem na lógica da aplicação.

### 6. Feedback Visual Imediato

O servidor de desenvolvimento do Manus oferece hot module reloading (HMR), permitindo ver mudanças no código refletidas instantaneamente no navegador. Isso acelera o processo de iteração e torna o desenvolvimento mais interativo e satisfatório.

---

## ⚠️ Limitações Encontradas

### 1. Limitações da Geração de Código por IA

Embora o Manus AI tenha gerado a maior parte do código funcional, houve necessidade de correções manuais em alguns pontos. Especificamente, o TypeScript exigiu ajustes em tipagem de refs e tratamento de estado para garantir type-safety. A IA gerou código logicamente correto, mas com algumas imprecisões em tipos TypeScript que precisaram ser refinadas manualmente. Isso demonstra que, apesar dos avanços, a IA ainda requer validação e refinamento humano.

### 2. Dependência da Plataforma Manus

O projeto está totalmente acoplado à plataforma Manus. Embora isso seja vantajoso para desenvolvimento rápido, significa que migrar o projeto para outra plataforma (por exemplo, Vercel, Netlify) exigiria refatoração de configurações e possivelmente ajustes de código. Não há portabilidade automática para outras stacks.

### 3. Limitações de Performance em Grids Muito Grandes

A implementação atual usa Canvas para renderização, o que é eficiente para grids 20x20, mas poderia enfrentar limitações de performance em grids significativamente maiores (por exemplo, 100x100). Para aplicações com requisitos de performance extrema, seria necessário otimizações adicionais ou uso de WebGL.

### 4. Falta de Persistência de Dados

O jogo não possui sistema de salvamento de pontuações ou histórico de partidas. Todas as informações são perdidas ao recarregar a página. Implementar persistência exigiria integração com banco de dados, o que está fora do escopo atual.

### 5. Ausência de Funcionalidades Avançadas

O escopo atual implementa apenas o jogo básico. Funcionalidades como múltiplos níveis, power-ups, diferentes modos de jogo, ou multiplayer não foram incluídas. Embora essas funcionalidades possam ser adicionadas, exigiriam esforço de desenvolvimento adicional.

### 6. Limitações de Acessibilidade

Embora o jogo seja funcional, a interface poderia ser mais acessível para usuários com deficiências visuais ou motoras. Por exemplo, não há suporte a leitores de tela, e o jogo depende inteiramente de entrada via teclado/mouse.

---

## 📚 Reflexão Crítica

### Como o Grupo Lidou com as Limitações

Diante das limitações identificadas, o grupo adotou as seguintes estratégias:

**Validação e Refinamento de Código:**
Embora o Manus AI tenha gerado a maior parte do código, foi necessário revisar cuidadosamente a implementação, especialmente em relação a tipagem TypeScript. O grupo validou que o código gerado era logicamente correto e funcionava como esperado, mas fez ajustes pontuais para garantir conformidade com padrões de tipo-segurança. Isso demonstra que a IA é uma ferramenta poderosa, mas requer supervisão humana.

**Aceitação Estratégica de Trade-offs:**
O grupo reconheceu que otimizar para performance extrema ou implementar funcionalidades avançadas teria consumido tempo significativo. Em vez disso, priorizou a entrega de um produto mínimo viável (MVP) que demonstrasse claramente o conceito de Engenharia de Prompt. Essa abordagem pragmática permitiu focar nos objetivos pedagógicos da disciplina.

**Design como Diferencial:**
Para contornar a limitação de funcionalidades básicas, o grupo investiu em design visual sofisticado (tema Retro Arcade Neon). Isso criou uma experiência memorável e demonstrou que, mesmo com funcionalidades simples, design cuidadoso pode criar valor significativo. O efeito glow neon, animações pulsantes e interface intuitiva elevaram a qualidade percebida do produto.

**Documentação Clara:**
O grupo reconheceu que a documentação clara é crucial para comunicar tanto as capacidades quanto as limitações do produto. Essa documentação serve como referência para futuras melhorias e demonstra compreensão crítica do projeto.

**Planejamento para Escalabilidade:**
Embora o escopo atual seja limitado, o código foi estruturado de forma modular, permitindo que funcionalidades futuras (como múltiplos níveis, power-ups, ou persistência de dados) possam ser adicionadas com mínima refatoração. Isso demonstra pensamento estratégico sobre evolução do produto.

---

## 👥 Colaboração

### Organização das Tarefas e Responsabilidades

O projeto foi desenvolvido através de uma abordagem colaborativa onde cada membro contribuiu com suas competências específicas:

**Engenharia de Prompt:**
Um membro focou em craftar prompts precisos e iterativos para o Manus AI, refinando as descrições até obter código de qualidade. Isso incluiu múltiplas iterações para ajustar a lógica do jogo, a estrutura de componentes React, e o design visual.

**Validação e Refinamento de Código:**
Outro membro revisou o código gerado pela IA, identificou imprecisões em tipagem TypeScript, e implementou correções. Isso garantiu que o código não apenas funcionasse, mas também seguisse boas práticas de desenvolvimento.

**Design e Estilização:**
Um terceiro membro trabalhou na concepção do tema visual Retro Arcade Neon, definindo a paleta de cores, efeitos visuais, e animações. Isso envolveu pesquisa de design, prototipagem visual, e refinamento iterativo.

**Documentação e Apresentação:**
Um quarto membro focou em documentar o processo, capturar screenshots, e redigir esta documentação. Isso garantiu que o trabalho fosse comunicado claramente e que as aprendizagens fossem preservadas.

**Integração e Testes:**
Todos os membros participaram de testes funcionais, verificando que o jogo funcionava como esperado em diferentes navegadores e dispositivos, e que a experiência do usuário era intuitiva.

Essa divisão de responsabilidades permitiu que o grupo trabalhasse eficientemente, aproveitando as competências individuais enquanto mantinha coesão no projeto.

---

## 📝 Registro da Aula

| Campo | Informação |
|-------|-----------|
| **Data** | 26 de maio de 2026 |
| **Atividade** | Desenvolvimento de aplicação funcional usando Engenharia de Prompt e IA |
| **Local** | Laboratório de Informática / Ambiente Virtual (Manus) |
| **Professor(a)** | Kadidja Valéria |
| **Disciplina** | Engenharia de Prompt - Módulo 3 (Low Code/No Code/Vibecode) |
| **Duração** | Sessão de desenvolvimento iterativo |

### Discussão Crítica Realizada

Durante a aula, o grupo engajou em discussão crítica sobre:

- **Efetividade da IA na Geração de Código:** Avaliou-se que a IA é altamente efetiva para gerar código estruturado e funcional, mas requer validação humana para garantir qualidade e conformidade com padrões.

- **Trade-offs entre Velocidade e Qualidade:** Discutiu-se como a priorização de prototipagem rápida pode, em alguns casos, resultar em código que requer refinamento posterior. O grupo concluiu que essa é uma troca aceitável em contextos de inovação rápida.

- **Importância do Design:** Reconheceu-se que, mesmo com funcionalidades simples, design cuidadoso pode criar experiências memoráveis e agregar valor significativo.

- **Futuro do Desenvolvimento:** Refletiu-se sobre como ferramentas de IA provavelmente transformarão a indústria de desenvolvimento de software, elevando o foco de "como programar" para "como especificar e validar requisitos".

---

## 🚀 Próximos Passos

### Melhorias Sugeridas para o Protótipo

1. **Sistema de Pontuação Persistente:** Implementar localStorage ou integração com banco de dados para salvar e exibir histórico de pontuações máximas.

2. **Múltiplos Níveis de Dificuldade:** Adicionar seleção de dificuldade que afeta velocidade inicial e comportamento de inimigos (se implementados).

3. **Power-ups e Obstáculos:** Introduzir elementos especiais como power-ups que aumentam velocidade ou congelam o tempo, e obstáculos que aumentam desafio.

4. **Modo Multiplayer Local:** Implementar suporte para dois jogadores na mesma tela com controles separados.

5. **Acessibilidade Melhorada:** Adicionar suporte a leitores de tela, modo de alto contraste, e controles alternativos para usuários com deficiências motoras.

6. **Efeitos Sonoros:** Integrar áudio para feedback de ações (coleta de comida, colisão, game over).

7. **Responsividade Móvel:** Otimizar para telas menores e adicionar controles touchscreen.

### Possíveis Evoluções para o Projeto Final da Unidade 3

O projeto pode evoluir em várias direções para o projeto final:

**Direção 1 - Jogo Completo:**
Expandir o jogo da cobrinha em uma aplicação completa com múltiplos modos de jogo, sistema de ranking global (com backend), e integração com redes sociais para compartilhamento de pontuações.

**Direção 2 - Plataforma de Jogos Retrô:**
Generalizar o conceito para criar uma plataforma que hospede múltiplos jogos clássicos (Pac-Man, Space Invaders, Tetris) todos com tema visual unificado e sistema de pontuação compartilhado.

**Direção 3 - Ferramenta de Educação em IA:**
Transformar o projeto em uma ferramenta educacional que demonstra como IA pode ser usada para gerar código, incluindo interface para experimentar diferentes prompts e ver o código gerado.

**Direção 4 - Análise de Efetividade de Engenharia de Prompt:**
Conduzir estudo comparativo entre código gerado por IA vs. código escrito manualmente, medindo métricas como tempo de desenvolvimento, qualidade de código, e manutenibilidade.

---

## 📊 Conclusão

Este projeto demonstrou com sucesso como **Engenharia de Prompt e ferramentas de IA podem ser utilizadas para acelerar significativamente o desenvolvimento de aplicações interativas**. O jogo da cobrinha funcional foi criado em tempo reduzido, mantendo qualidade visual e funcional, através de uma combinação efetiva de:

- **Prompt Engineering:** Comunicação clara de requisitos à IA
- **Validação Humana:** Revisão crítica e refinamento de código gerado
- **Design Cuidadoso:** Criação de experiência visual memorável
- **Colaboração Efetiva:** Divisão estratégica de responsabilidades

As limitações identificadas não diminuem o valor do projeto, mas sim reforçam a importância de compreender tanto as capacidades quanto as restrições das ferramentas de IA. O projeto serve como base sólida para futuras evoluções e demonstra o potencial transformador da IA no desenvolvimento de software.

---

**Desenvolvido por:** Grupo de Engenharia de Prompt  
**Data de Conclusão:** 26 de maio de 2026  
**Plataforma:** Manus AI + React 19 + Tailwind CSS 4  
**Status:** ✅ Funcional e Documentado
